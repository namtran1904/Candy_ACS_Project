import cv2
import torch
import torch.nn as nn
from torchvision import transforms, models
from ultralytics import RTDETR
from PIL import Image

if(torch.cuda.is_availabe()):
    device = torch.device ("cuda")
else:
    device = torch.device("cpu")
print(f" Đang chạy trên nền tảng: {device}")

#nạp mô mình detect
detector = RTDETR("rtdetr-l.pt")
print(f"Nạp thành công mô hình Detect (RT-DETR)!")


